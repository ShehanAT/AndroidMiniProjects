package com.coding.informer.androidviewmodelexample

const val SPLASH_DELAY = 3000
const val BASE_URL = "https://hf-android-app.s3-eu-west-1.amazonaws.com/android-test/"
const val EXPENSE_ITEM_KEY = ""
const val SHARED_PREFERRENCE_FILE_NAME = ""
const val FAVOURITES_KEY = ""