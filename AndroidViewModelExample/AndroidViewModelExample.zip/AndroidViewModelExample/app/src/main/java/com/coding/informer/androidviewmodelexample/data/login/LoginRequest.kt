package com.coding.informer.androidviewmodelexample.data.login

/**
 * Created by AhmedEltaher
 */
data class LoginRequest(val email: String, val password: String){
}