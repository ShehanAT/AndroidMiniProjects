package com.coding.informer.androidviewmodelexample.views.component.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.coding.informer.androidviewmodelexample.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}