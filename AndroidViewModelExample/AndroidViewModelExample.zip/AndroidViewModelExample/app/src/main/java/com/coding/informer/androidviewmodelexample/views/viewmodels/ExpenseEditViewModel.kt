package com.coding.informer.androidviewmodelexample.views.viewmodels

import androidx.lifecycle.ViewModel
import com.coding.informer.androidviewmodelexample.models.Expense

class ExpenseEditViewModel: ViewModel() {
    private var expense: Expense? = null





}