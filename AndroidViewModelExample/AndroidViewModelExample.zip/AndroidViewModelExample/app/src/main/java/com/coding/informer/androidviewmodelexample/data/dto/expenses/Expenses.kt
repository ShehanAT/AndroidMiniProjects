package com.coding.informer.androidviewmodelexample.data.dto.expenses

data class Expenses(val expenseList: ArrayList<ExpensesItem>) {
}